#ifndef HASHTABLE_H
#define HASHTABLE_H


class hashTable
{
    public:
        hashTable();
        virtual ~hashTable();

    protected:

    private:
};

#endif // HASHTABLE_H
